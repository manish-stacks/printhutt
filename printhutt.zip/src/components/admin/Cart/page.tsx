import React from 'react'

const User_Cart = () => {
  return (
    <div>User_Cart</div>
  )
}

export default User_Cart