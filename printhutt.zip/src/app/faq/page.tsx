import FAQ from "@/pages/FAQ"

// export const metadata = {
//   title: 'faq',
//   description: 'faq',
// }

const faqPage = () => {
  return <FAQ />
}

export default faqPage