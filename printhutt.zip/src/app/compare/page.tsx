// import Compare from "@/pages/Compare"
import { notFound } from "next/navigation"


const ComparePage = () => {

  return (
    notFound()
  )
  //return <Compare />
}

export default ComparePage