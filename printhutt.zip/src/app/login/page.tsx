import Login from "@/pages/Login"

export const metadata = {
  title: 'Login',
  description: 'login',
}
const LoginPage = () => {
  
  return <Login />


}

export default LoginPage