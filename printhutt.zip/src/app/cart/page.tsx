import Cart from "@/pages/Cart"

const ContectPage = () => {
  return <Cart />
}

export default ContectPage