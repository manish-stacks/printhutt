import ContactUs from "@/pages/ContactUs"


// export const metadata = {
//   title: 'contact-us',
//   description: 'contact-us',
// }

const ContectPage = () => {
  return <ContactUs />
}

export default ContectPage