import AboutUs from "@/pages/AboutUs"


const AboutPage= () => {
  return <AboutUs />
}

export default AboutPage
