import { Font } from "@/lib/types/neon";


export const fonts: Font[] = [
  { name: 'Barcelona', value: 'Buttervill' }
];