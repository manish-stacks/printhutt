import UserDashboard from "@/pages/user/Dashboard";


const userDashboard = () => {
  return <UserDashboard />;
};

export default userDashboard;
