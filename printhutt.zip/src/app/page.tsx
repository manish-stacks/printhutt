
import HomeComponent from "@/pages/Home";
export default function Home() {

  return (
    <>
      <HomeComponent />
    </>
  );
}
