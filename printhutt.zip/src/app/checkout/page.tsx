import Checkout from "@/pages/Checkout";

// export const metadata = {
//   title: "checkout",
//   description: "checkout",
// };

const CheckoutPage = () => {
  return <Checkout />;
};

export default CheckoutPage;
