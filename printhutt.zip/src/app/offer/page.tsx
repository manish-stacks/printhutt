import Offer from "@/pages/Offer"

// export const metadata = {
//   title: 'offer',
//   description: 'offer',
// }

const offerPage = () => {
  return <Offer />
}

export default offerPage