import AdminDashboard from "@/pages/admin/Dashboard"

export const metadata = {
  title: 'Admin-dashboard',
  description: 'Dashboard-page',
}

const dashboardPage = () => {
  
  return <AdminDashboard />
}

export default dashboardPage