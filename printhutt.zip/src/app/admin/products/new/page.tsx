"use client";
import AddProduct from "@/pages/admin/product/add-product";

export default function EditProduct() {
    return <AddProduct/>
}