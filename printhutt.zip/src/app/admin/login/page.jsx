import Login from '@/pages/admin/Login'
import React from 'react'

const page = () => {
  return (
    <>
      <Login/>
    </>
  )
}

export default page