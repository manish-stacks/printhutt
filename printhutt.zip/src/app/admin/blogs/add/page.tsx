import BlogAdd from '@/pages/admin/blog/BlogAdd'
import React from 'react'

const page = () => {
  return <BlogAdd />
}

export default page