import BlogEdit from "@/pages/admin/blog/BlogEdit"

const Page = () => {
  return <BlogEdit />
}

export default Page