import CategoriesEdit from "@/pages/admin/categories/CategoriesEdit"

const Page = () => {
  return <CategoriesEdit />
}

export default Page