// import CategoriesAdd from '@/pages/admin/categories/CategoriesAdd'
import CategoriesAdd from '@/pages/admin/categories/CategoriesAdd'
import React from 'react'

const page = () => {
  return (
    <>
      <CategoriesAdd />
    </>
  )
}

export default page