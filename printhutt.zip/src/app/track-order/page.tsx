
import TrackOrder from '@/pages/TrackOrder'


// export const metadata = {
//   title: 'track order',
//   description: 'track order-page'
// }

const trackOrderPage = () => {
  
  return <TrackOrder />
}

export default trackOrderPage